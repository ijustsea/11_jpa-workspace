package food.eatery.domain;

public enum ReservStatus {
    RESERV, CANCEL
}
