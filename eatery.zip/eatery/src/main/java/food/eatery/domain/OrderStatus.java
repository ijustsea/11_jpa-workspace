package food.eatery.domain;

public enum OrderStatus {
    ORDER, CANCEL
}
