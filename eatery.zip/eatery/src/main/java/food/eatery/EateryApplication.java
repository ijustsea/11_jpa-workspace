package food.eatery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EateryApplication {

	public static void main(String[] args) {
		SpringApplication.run(EateryApplication.class, args);
	}

}
